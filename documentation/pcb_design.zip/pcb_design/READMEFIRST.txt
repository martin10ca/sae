Carpetas diseño PCB:
1) Footprints$3D: librerias de modelo 3d y footprints en formato .lib
2) diseño altium: archivo de PCB, esquemático, salida y archivo proyecto unificado.
3) JuanHernandez_SAE_11-19-2025_Rev1: formato de entrega para fabricación en formato Gerber Files y NC Drill Files (perforaciones circulares)

OJO: Error en esquematico en GND del adc1, es decir, en pin 9. Error en pines para sensor de distancia A0.